// MasterBot Bridge — background service worker.
// Acts as a generic transport for the MasterBot site to call Jobber's
// and MAPRO's internal APIs using the user's existing Brave/Chrome
// session cookies. No data is stored anywhere; the extension only
// relays requests and returns responses to the calling page.

const JOBBER_GRAPHQL = "https://secure.getjobber.com/api/graphql?location=j";
const MAPRO_BASE = "https://app.mapro.us";

async function jobberFetch({ operationName, query, variables }) {
    if (typeof query !== "string" || !query.trim()) {
        throw new Error("query is required");
    }
    const res = await fetch(JOBBER_GRAPHQL, {
        method: "POST",
        credentials: "include",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Requested-With": "XMLHttpRequest",
            "X-Jobber-Graphql-Version": "2026-04-16",
        },
        body: JSON.stringify({ operationName, query, variables: variables || {} }),
    });
    const text = await res.text();
    let json;
    try {
        json = JSON.parse(text);
    } catch (_) {
        throw new Error(`Non-JSON response (HTTP ${res.status}): ${text.slice(0, 300)}`);
    }
    if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${json?.errors?.[0]?.message || text.slice(0, 300)}`);
    }
    if (Array.isArray(json.errors) && json.errors.length) {
        throw new Error(json.errors[0].message || "GraphQL error");
    }
    return json.data;
}

async function openBookingTab(reservaId) {
    // Open as a non-focused background tab in the current window. Visible in
    // the tab strip briefly but reliable across browsers (Brave was silently
    // failing on chrome.windows.create({state:"minimized"})).
    const url = `https://app.mapro.us/booking/reservation/${encodeURIComponent(reservaId)}`;
    console.log("[MB-bg] opening booking tab:", url);
    let tab;
    try {
        tab = await chrome.tabs.create({ url, active: false });
    } catch (e) {
        console.error("[MB-bg] chrome.tabs.create failed:", e);
        throw new Error("tabs.create failed: " + (e?.message || e));
    }
    console.log("[MB-bg] tab created id=" + tab.id);
    await new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(onUpdated);
            reject(new Error("tab load timed out after 20s"));
        }, 20000);
        const onUpdated = (tabId, changeInfo) => {
            if (tabId === tab.id && changeInfo.status === "complete") {
                clearTimeout(timeout);
                chrome.tabs.onUpdated.removeListener(onUpdated);
                resolve();
            }
        };
        chrome.tabs.onUpdated.addListener(onUpdated);
    });
    console.log("[MB-bg] tab loaded, waiting for MAPRO JS init...");
    await new Promise((r) => setTimeout(r, 800));
    return { tabId: tab.id };
}

async function maproAddService({ reservaId, kind, price, startDate, endDate, dryRun, force, checkOnly }) {
    console.log("[MB-bg] mapro-add-service called:", { reservaId, kind, price, startDate, endDate, dryRun: !!dryRun, force: !!force, checkOnly: !!checkOnly });
    if (!reservaId) throw new Error("reservaId required");
    if (!kind) throw new Error("kind required (bbq|ph)");
    if (price == null || isNaN(Number(price))) throw new Error("price required (number)");
    if (!startDate || !/^\d{4}-\d{2}-\d{2}$/.test(String(startDate))) throw new Error("startDate required (YYYY-MM-DD)");
    if (!endDate || !/^\d{4}-\d{2}-\d{2}$/.test(String(endDate))) throw new Error("endDate required (YYYY-MM-DD)");

    const { tabId } = await openBookingTab(reservaId);
    try {
        console.log("[MB-bg] running pageRunner via chrome.scripting in MAIN world");
        const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: pageRunner,
            args: [{ kind, startDate, endDate, dryRun: !!dryRun, force: !!force }],
        });
        const wrapped = results && results[0] && results[0].result;
        console.log("[MB-bg] pageRunner returned:", wrapped);
        if (!wrapped) throw new Error("pageRunner returned no result");
        if (!wrapped.ok) throw new Error(wrapped.error || "pageRunner returned error");
        return wrapped.data;
    } finally {
        chrome.tabs.remove(tabId).catch((e) => console.warn("[MB-bg] failed to close tab:", e));
    }
}

// Runs in the booking page's MAIN world (has access to add_service, jQuery, uuid).
// Must be self-contained — no closures over outer variables.
async function pageRunner(cfg) {
    try {
        const { kind, startDate, endDate, dryRun, force } = cfg;
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

        // Wait for booking form to load
        const tForm = Date.now();
        while (Date.now() - tForm < 15000) {
            if (document.querySelector('form[data-ajax="booking-reservar"] select[name="id"]')) break;
            await sleep(150);
        }
        const sampleSelect = document.querySelector('form[data-ajax="booking-reservar"] select[name="id"]');
        if (!sampleSelect) throw new Error("Booking form did not load (15s)");

        // Para BBQ: checa se já existe BBQ no mesmo dia ANTES de adicionar.
        // Se existe e não é force, retorna status:duplicate pra UI confirmar.
        if (kind === "bbq" && !force) {
            const existing = Array.from(document.querySelectorAll('form[data-ajax="booking-reservar"] .reservation-service-container'));
            for (const c of existing) {
                const sel = c.querySelector('select[name="id"]');
                const startInp = c.querySelector('input[name="start_date"]');
                if (!sel || !startInp) continue;
                const optEl = sel.options[sel.selectedIndex];
                const label = optEl ? (optEl.textContent || "").trim() : "";
                if (/\bbbq\b/i.test(label) && startInp.value === startDate) {
                    return { ok: true, data: { status: "duplicate", existingLabel: label, existingDate: startInp.value } };
                }
            }
        }

        // Service matching strategy varies per kind:
        //   bbq → first option containing "bbq"
        //   ph  → "pool heat" option whose label price > 0 (skips the $0 Variable one)
        const allOpts = Array.from(sampleSelect.options).filter((o) => o.value);
        const parsePrice = (text) => {
            const m = String(text || "").match(/\$\s*([\d.,]+)/);
            if (!m) return null;
            return parseFloat(m[1].replace(/,/g, ""));
        };
        let opt;
        if (kind === "bbq") {
            opt = allOpts.find((o) => /\bbbq\b/i.test(o.textContent));
        } else if (kind === "ph") {
            const phOpts = allOpts.filter((o) => /pool\s*heat/i.test(o.textContent));
            opt = phOpts.find((o) => {
                const p = parsePrice(o.textContent);
                return p != null && p > 0;
            });
            if (!opt && phOpts.length) {
                throw new Error("Pool Heat options found but none with price > 0: " + phOpts.map((o) => o.textContent.trim()).join(" | "));
            }
        } else {
            throw new Error("Unknown service kind: " + kind);
        }
        if (!opt) {
            const available = allOpts.map((o) => o.textContent.trim()).join(" | ");
            throw new Error(`No "${kind}" service. Available: ${available}`);
        }
        const serviceId = opt.value;
        const serviceLabel = opt.textContent.trim();

        if (typeof window.add_service !== "function") throw new Error("MAPRO add_service is not defined");
        if (typeof window.uuid === "undefined" || !window.uuid.v4) throw new Error("MAPRO uuid is not defined");

        const before = document.querySelectorAll('form[data-ajax="booking-reservar"] .reservation-service-container').length;
        window.add_service({
            onlyActive: 1, servico_padrao: 0,
            valor: "0.00", valor_desconto: "0.00",
            valor_sale: "0.00", valor_tourist: "0.00",
            display: "none",
        }, window.uuid.v4());

        // Wait for new service container
        const tBlock = Date.now();
        while (Date.now() - tBlock < 5000) {
            if (document.querySelectorAll('form[data-ajax="booking-reservar"] .reservation-service-container').length > before) break;
            await sleep(100);
        }
        const containers = document.querySelectorAll('form[data-ajax="booking-reservar"] .reservation-service-container');
        if (containers.length <= before) throw new Error("Service block did not appear after add_service()");
        const newContainer = containers[containers.length - 1];
        const innerSel = newContainer.querySelector('select[name="id"]');
        if (!innerSel) throw new Error("New service has no select");

        const $ = window.jQuery || window.$;
        if ($) {
            $(innerSel).val(serviceId).trigger("change");
        } else {
            innerSel.value = serviceId;
            innerSel.dispatchEvent(new Event("change", { bubbles: true }));
        }
        await sleep(200);

        // PH precisa de range (start/end). Sobreescreve as datas que MAPRO autopreencheu.
        // MAPRO provavelmente usa flatpickr/datepicker — tentamos múltiplas abordagens.
        const dateDebug = {};
        if (kind === "ph" && startDate && endDate) {
            // Snapshot de todos os inputs do bloco (debug pra entender quais existem)
            dateDebug.allInputs = Array.from(newContainer.querySelectorAll("input,select,textarea"))
                .filter((i) => i.name)
                .map((i) => ({ name: i.name, type: i.type, value: i.value }));

            const nativeInputSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
            const setDate = (inp, iso, label) => {
                if (!inp) {
                    dateDebug[label] = "input not found";
                    return;
                }
                const before = inp.value;
                if (inp._flatpickr) {
                    try { inp._flatpickr.setDate(iso, true); }
                    catch (e) { dateDebug[label + "_fp_err"] = String(e?.message || e); }
                }
                try { nativeInputSetter.call(inp, iso); } catch (_) { inp.value = iso; }
                inp.dispatchEvent(new Event("input", { bubbles: true }));
                inp.dispatchEvent(new Event("change", { bubbles: true }));
                inp.dispatchEvent(new Event("blur", { bubbles: true }));
                if ($) {
                    try { $(inp).val(iso).trigger("change").trigger("blur"); } catch (_) {}
                }
                dateDebug[label + "_name"] = inp.name;
                dateDebug[label] = { before, requested: iso, after: inp.value };
            };

            // Tenta múltiplos seletores até achar o input certo:
            //  1. name$="[start_date]" (services[N][start_date])
            //  2. name="start_date"
            //  3. name contém "start" + "date"
            //  4. type=date e o primeiro do bloco
            const findInput = (kw) => {
                let inp = newContainer.querySelector(`input[name$="[${kw}]"]`);
                if (inp) return inp;
                inp = newContainer.querySelector(`input[name="${kw}"]`);
                if (inp) return inp;
                const re = new RegExp("\\b" + kw.replace("_", "[_\\s-]?") + "\\b", "i");
                inp = Array.from(newContainer.querySelectorAll("input"))
                    .find((i) => i.name && re.test(i.name));
                return inp || null;
            };
            const startInput = findInput("start_date");
            const endInput = findInput("end_date");
            setDate(startInput, startDate, "start");
            setDate(endInput, endDate, "end");
            await sleep(400);
            if (startInput) dateDebug.start_final = startInput.value;
            if (endInput) dateDebug.end_final = endInput.value;
            console.log("[MB-page] PH date set:", JSON.stringify(dateDebug));
        }

        if (dryRun) {
            const fields = Array.from(newContainer.querySelectorAll("input,select,textarea"))
                .filter((i) => i.name)
                .map((i) => ({ name: i.name, value: i.value }));
            return { ok: true, data: { serviceId, serviceLabel, status: "dry-run", fields, dateDebug } };
        }

        const saveLink = Array.from(document.querySelectorAll('a.bt2[data-submit]'))
            .filter((a) => (a.textContent || "").trim() === "Save")
            .find((a) => a.offsetParent !== null);
        if (!saveLink) throw new Error("Save button not found");

        // Hook XHR before clicking Save to capture the booking-reservar response
        // (more reliable than guessing what success/error DOM looks like).
        let bookingResp = null;
        let bookingErr = null;
        const origOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (m, u) {
            if (u && /booking-reservar/.test(u)) {
                this.addEventListener("load", () => {
                    try { bookingResp = JSON.parse(this.responseText); }
                    catch (_) { bookingResp = { raw: (this.responseText || "").slice(0, 400) }; }
                });
                this.addEventListener("error", () => { bookingErr = "XHR network error"; });
            }
            return origOpen.apply(this, arguments);
        };

        if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
        const init = { bubbles: true, cancelable: true, view: window, button: 0 };
        saveLink.dispatchEvent(new MouseEvent("mousedown", { ...init, buttons: 1 }));
        saveLink.dispatchEvent(new MouseEvent("mouseup", { ...init, buttons: 0 }));
        saveLink.dispatchEvent(new MouseEvent("click", { ...init, buttons: 0 }));

        const tWatch = Date.now();
        while (Date.now() - tWatch < 10000) {
            if (bookingResp) {
                // MAPRO usually returns {status: true} on success
                if (bookingResp.status === true || bookingResp.success === true) {
                    return { ok: true, data: { serviceId, serviceLabel, status: "saved", dateDebug } };
                }
                throw new Error("MAPRO save failed: " + (bookingResp.msg || JSON.stringify(bookingResp).slice(0, 300)));
            }
            if (bookingErr) throw new Error(bookingErr);
            // Fallback DOM signals (in case XHR hook is racy):
            const errEls = Array.from(document.querySelectorAll(".f-erro.reserva-erro")).filter((el) => el.offsetParent !== null);
            const okEls = Array.from(document.querySelectorAll(".f-sucesso.reserva-sucesso")).filter((el) => el.offsetParent !== null);
            if (okEls.length) return { ok: true, data: { serviceId, serviceLabel, status: "saved" } };
            if (errEls.length) {
                const msg = errEls.map((el) => el.textContent.trim()).join(" | ");
                throw new Error("MAPRO error: " + msg);
            }
            await sleep(150);
        }
        throw new Error("Save: no XHR response within 10s");
    } catch (e) {
        return { ok: false, error: String(e?.message || e) };
    }
}

async function maproListServices({ reservaId }) {
    if (!reservaId) throw new Error("reservaId required");
    console.log("[MB-bg] mapro-list-services for reserva", reservaId);
    const { tabId } = await openBookingTab(reservaId);
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: async () => {
                try {
                    const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
                    const tForm = Date.now();
                    while (Date.now() - tForm < 8000) {
                        if (document.querySelector('form[data-ajax="booking-reservar"] .reservation-service-container')) break;
                        await sleep(150);
                    }
                    const containers = document.querySelectorAll('form[data-ajax="booking-reservar"] .reservation-service-container');
                    const services = [];
                    for (const c of containers) {
                        const sel = c.querySelector('select[name="id"]');
                        const startInp = c.querySelector('input[name="start_date"]');
                        const endInp = c.querySelector('input[name="end_date"]');
                        if (!sel) continue;
                        const opt = sel.options[sel.selectedIndex];
                        services.push({
                            label: opt ? (opt.textContent || "").trim() : "",
                            value: sel.value,
                            start_date: startInp ? startInp.value : "",
                            end_date: endInp ? endInp.value : "",
                        });
                    }
                    return { ok: true, data: { services } };
                } catch (e) {
                    return { ok: false, error: String(e?.message || e) };
                }
            },
        });
        const wrapped = results && results[0] && results[0].result;
        if (!wrapped) throw new Error("listServices: no result");
        if (!wrapped.ok) throw new Error(wrapped.error || "listServices failed");
        return wrapped.data;
    } finally {
        chrome.tabs.remove(tabId).catch(() => {});
    }
}

async function maproAddComment({ reservaId, casaId, comment }) {
    if (!reservaId) throw new Error("reservaId missing (got " + JSON.stringify(reservaId) + ")");
    if (!casaId) throw new Error("casaId missing (got " + JSON.stringify(casaId) + ")");
    if (typeof comment !== "string" || !comment.trim()) throw new Error("comment is required");
    const fd = new FormData();
    fd.append("tx-comentario", comment);
    fd.append("reserva_id", String(reservaId));
    fd.append("casa_id", String(casaId));
    fd.append("comentario", comment);
    const res = await fetch(MAPRO_BASE + "/ajax?manage-booking-details-commented", {
        method: "POST",
        credentials: "include",
        headers: {
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
        },
        body: fd,
    });
    const text = await res.text();
    let json;
    try { json = JSON.parse(text); }
    catch (_) { throw new Error(`Non-JSON response (HTTP ${res.status}): ${text.slice(0, 200)}`); }
    if (!res.ok || json?.status !== true) {
        throw new Error(json?.msg || `HTTP ${res.status}`);
    }
    return json;
}

// ====================================================================
// GATE ACCESS (gateaccess.net) — Champions Gate guest submission.
// Reads credentials from a hardcoded Google Sheet using the user's own
// Google session cookies. Cache lives only in chrome.storage.local; no
// credentials ever leave the extension sandbox.
// ====================================================================

// Sheet ID from the URL: https://docs.google.com/spreadsheets/d/<ID>/edit
const GATE_SHEET_ID = "15rnSnXSX9jOkxR0Gn9teNs3WUJYIHeWf_RzN1hzDBRg";
// gid of the "Windsor Cay - Gate" tab inside the GATE ACCESS spreadsheet.
const GATE_SHEET_GID = "701856462";

const GATE_BASE = "https://gateaccess.net";
// Cache key was bumped (v2) when we switched from a house-keyed map to a
// rows-array. Old caches stored only Champions Gate rows because of a
// hard-coded filter and collided on house="ALL HOMES" anyway, so we
// invalidate them on first read.
const GATE_CREDS_CACHE_KEY = "gateCredsCacheV2";
const GATE_CREDS_TTL_MS = 24 * 60 * 60 * 1000;

function gateNormalizeHouse(s) {
    return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

// Minimal RFC-4180-ish CSV parser (handles quoted fields with commas/newlines).
function gateParseCsv(text) {
    const rows = [];
    let row = [];
    let cur = "";
    let inQuote = false;
    for (let i = 0; i < text.length; i++) {
        const c = text[i];
        if (inQuote) {
            if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; }
            else if (c === '"') { inQuote = false; }
            else { cur += c; }
        } else {
            if (c === '"') { inQuote = true; }
            else if (c === ',') { row.push(cur); cur = ""; }
            else if (c === '\n') { row.push(cur); rows.push(row); row = []; cur = ""; }
            else if (c === '\r') { /* skip */ }
            else { cur += c; }
        }
    }
    if (cur || row.length) { row.push(cur); rows.push(row); }
    return rows;
}

async function gateFetchSheetCsv() {
    if (!GATE_SHEET_ID || GATE_SHEET_ID.startsWith("REPLACE_")) {
        throw new Error("GATE_SHEET_ID is not set in extension/background.js");
    }
    // /export with explicit gid targets a specific tab (default returns the
    // first sheet only). Redirects to *.googleusercontent.com, so both hosts
    // must be in host_permissions.
    const url = `https://docs.google.com/spreadsheets/d/${GATE_SHEET_ID}/export?format=csv&gid=${GATE_SHEET_GID}`;
    let res;
    try {
        res = await fetch(url, { credentials: "include" });
    } catch (e) {
        throw new Error(
            "Could not reach the Gate Access sheet. Reload the extension at " +
            "chrome://extensions, sign in to the Google account that owns the " +
            "sheet, and try again. Underlying error: " + (e?.message || e)
        );
    }
    if (!res.ok) {
        throw new Error(`Sheet HTTP ${res.status} — check the sheet ID and that the account has access`);
    }
    const text = await res.text();
    if (/<html/i.test(text.slice(0, 200))) {
        throw new Error("Sheet returned HTML instead of CSV — sign in to the right Google account, or check sheet permissions");
    }
    return text;
}

function gateBuildMap(csvText) {
    const rows = gateParseCsv(csvText);
    if (rows.length < 2) throw new Error("Sheet has no data rows");

    let headerIdx = -1;
    for (let i = 0; i < rows.length; i++) {
        const norm = rows[i].map(gateNormalizeHouse);
        const hasHouse = norm.some((c) => c === "house" || c.includes("house"));
        const hasUser  = norm.some((c) => c.includes("user"));
        const hasPass  = norm.some((c) => c.includes("password") || c === "pass");
        if (hasHouse && hasUser && hasPass) {
            headerIdx = i;
            break;
        }
    }
    if (headerIdx === -1) {
        const preview = rows.slice(0, 6).map((r) => r.join(" | ")).join("  //  ");
        throw new Error("Header row not found (expected HOUSE / USER NAME / PASSWORD). First rows: " + preview);
    }

    const header = rows[headerIdx].map(gateNormalizeHouse);
    const findCol = (...names) => {
        for (const n of names) {
            const idx = header.indexOf(gateNormalizeHouse(n));
            if (idx >= 0) return idx;
        }
        for (const n of names) {
            const target = gateNormalizeHouse(n);
            const idx = header.findIndex((c) => c.includes(target));
            if (idx >= 0) return idx;
        }
        return -1;
    };
    const houseCol = findCol("house");
    const resortCol = findCol("resort");
    const userCol = findCol("user name", "username", "user");
    const passCol = findCol("password", "pass");
    const ccCol = findCol("community code", "community", "cc");

    if (houseCol < 0 || userCol < 0 || passCol < 0) {
        throw new Error("Missing column. Header: " + header.join(" | "));
    }

    // Store rows as an array. The previous implementation keyed by house
    // and silently lost rows when several entries shared the same house
    // value (e.g. all the "ALL HOMES" rows for resorts where one login
    // covers every property — Apartment MIAMI, Venetian Bay Villages,
    // Windsor Island Resort).
    const out = [];
    for (let i = headerIdx + 1; i < rows.length; i++) {
        const r = rows[i];
        const house = (r[houseCol] || "").trim();
        const user = (r[userCol] || "").trim();
        const pass = (r[passCol] || "").trim();
        const resort = resortCol >= 0 ? (r[resortCol] || "").trim() : "";
        const cc = ccCol >= 0 ? (r[ccCol] || "").trim() : "";
        if (!house || !user || !pass) continue;
        out.push({
            house, resort, username: user, password: pass,
            communityCode: cc || "",
        });
    }
    return out;
}

async function gateGetCacheRaw() {
    const data = await chrome.storage.local.get(GATE_CREDS_CACHE_KEY);
    const cache = data[GATE_CREDS_CACHE_KEY];
    if (!cache || !cache.ts || !Array.isArray(cache.rows)) return null;
    if (Date.now() - cache.ts > GATE_CREDS_TTL_MS) return null;
    return cache;
}

async function gateSetCache(rows) {
    await chrome.storage.local.set({
        [GATE_CREDS_CACHE_KEY]: { ts: Date.now(), rows },
    });
}

async function gateLoadRows() {
    let cache = await gateGetCacheRaw();
    if (cache) return cache.rows;
    const csv = await gateFetchSheetCsv();
    const rows = gateBuildMap(csv);
    await gateSetCache(rows);
    return rows;
}

async function gateEnsureCreds() {
    const cache = await gateGetCacheRaw();
    if (cache) return { cached: true, rowCount: cache.rows.length };
    const rows = await gateLoadRows();
    return { cached: false, rowCount: rows.length, refreshed: true };
}

async function gateCredsStatus() {
    const cache = await gateGetCacheRaw();
    return {
        cached: !!cache,
        expiresAt: cache ? cache.ts + GATE_CREDS_TTL_MS : null,
        rowCount: cache ? cache.rows.length : 0,
    };
}

async function gateCredsForResort(resort) {
    const rows = await gateLoadRows();
    const want = String(resort || "").toLowerCase().trim();
    if (!want) throw new Error("resort required");
    // Match by resort, then prefer the "ALL HOMES" master row. Some
    // resorts (Windsor Island) keep the all-properties Proptia login as
    // an ALL HOMES row plus extra per-house rows for individual resident
    // accounts. Picking the first match indiscriminately can land on a
    // resident account that only owns one or two houses, which then
    // can't find the requested property in the chooser.
    const matches = rows.filter((row) => {
        const have = String(row.resort || "").toLowerCase().trim();
        if (!have) return false;
        return have === want || have.includes(want) || want.includes(have);
    });
    if (matches.length === 0) {
        const sample = rows.map((r) => r.resort).filter(Boolean).slice(0, 8).join(" | ");
        throw new Error(
            `No gate credentials in the sheet for resort "${resort}". ` +
            `Resorts in sheet (${rows.length} rows): ${sample}`
        );
    }
    const master = matches.find((r) => /^all\s+homes?$/i.test(String(r.house || "").trim()));
    return master || matches[0];
}

async function gateCredsForHouse(house) {
    const rows = await gateLoadRows();
    const key = gateNormalizeHouse(house);
    // 1. Exact match
    for (const row of rows) {
        if (gateNormalizeHouse(row.house) === key) return row;
    }
    // 2. MAPRO uses "<number> <first-street-word>" (e.g. "453 Ocean") while
    //    the sheet has the full street ("453 Ocean Way"). Match by that prefix.
    const tokens = key.split(" ");
    if (tokens.length >= 2) {
        const prefix = tokens[0] + " " + tokens[1] + " ";
        for (const row of rows) {
            const k = gateNormalizeHouse(row.house);
            if (k === key || k.startsWith(prefix)) return row;
        }
    }
    // 3. Last-resort: leading number alone ("1601" → "1601 …")
    const numMatch = key.match(/^(\d+)/);
    if (numMatch) {
        const prefix = numMatch[1] + " ";
        for (const row of rows) {
            const k = gateNormalizeHouse(row.house);
            if (k.startsWith(prefix)) return row;
        }
    }
    throw new Error(`No gate credentials for "${house}". Make sure the house is in the sheet.`);
}

// Polls the tab via a tiny scripting.executeScript every ~250ms until the
// document body actually has children. "complete" fires too early on
// gateaccess.net — the body has 1 element for a while before DevExpress
// finishes painting.
async function gateWaitForPopulatedBody(tabId, timeoutMs = 30000) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeoutMs) {
        try {
            const res = await chrome.scripting.executeScript({
                target: { tabId },
                world: "MAIN",
                func: () => ({
                    bodyChildren: document.body ? document.body.children.length : 0,
                    hasSelect: !!document.querySelector("select"),
                    title: document.title,
                    pathname: location.pathname,
                }),
            });
            const r = res && res[0] && res[0].result;
            if (r && (r.hasSelect || r.bodyChildren >= 5)) return r;
        } catch (_) {
            // Tab may not be ready for scripting yet; keep polling.
        }
        await new Promise((r) => setTimeout(r, 250));
    }
    throw new Error("Page never populated within " + (timeoutMs / 1000) + "s");
}

async function gateWaitTabLoad(tabId, timeoutMs = 20000) {
    return new Promise((resolve, reject) => {
        const t = setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(onUpdated);
            reject(new Error("tab load timed out"));
        }, timeoutMs);
        const onUpdated = (id, info) => {
            if (id === tabId && info.status === "complete") {
                clearTimeout(t);
                chrome.tabs.onUpdated.removeListener(onUpdated);
                resolve();
            }
        };
        chrome.tabs.onUpdated.addListener(onUpdated);
    });
}

// ---------- Pure-HTTP gate automation ----------
//
// gateaccess.net is an ASP.NET WebForms + DevExpress site. We replicate the
// exact POST the browser sends when you click Update on the inline edit form
// (captured live via Playwright in 2026-05). Everything below — parsing
// hidden inputs, building the DevExpress callback string, submitting via
// fetch() with credentials:include — is so the extension never has to open
// a window or run any scripting in the page.

function gateParseHiddenInputs(html) {
    const inputs = {};
    const re = /<input\b([^>]*)>/gi;
    let m;
    while ((m = re.exec(html))) {
        const attrs = m[1];
        if (!/type\s*=\s*["']?hidden["']?/i.test(attrs)) continue;
        const nameMatch = /name\s*=\s*"([^"]*)"/i.exec(attrs) || /name\s*=\s*'([^']*)'/i.exec(attrs);
        const valueMatch = /value\s*=\s*"((?:[^"])*)"/i.exec(attrs) || /value\s*=\s*'([^']*)'/i.exec(attrs);
        if (nameMatch) {
            // HTML attributes use &amp;-encoded entities. Decode once so the
            // "logical" value matches what the browser would expose via .value
            // — re-encoding is URLSearchParams' job at POST time.
            inputs[nameMatch[1]] = valueMatch ? gateDecodeEntities(valueMatch[1]) : "";
        }
    }
    return inputs;
}

// The gridview's row keys + callback state aren't rendered as a hidden input
// in the static HTML — DevExpress writes the input from JS at runtime. We
// have to read the stateObject directly from the inline script literal.
// Anchored on the gridview's uniqueID so we don't pick up some other
// control's stateObject (BinaryImage1 etc.).
function gateExtractGridStateLiteral(html) {
    const anchor = html.indexOf("'uniqueID':'ctl00$ContentPlaceHolder1$ASPxGridView1'");
    if (anchor < 0) return null;
    const idx = html.indexOf("'stateObject'", anchor);
    if (idx < 0) return null;
    let i = html.indexOf("{", idx);
    if (i < 0) return null;
    const start = i;
    let depth = 0, inStr = false, esc = false;
    for (; i < html.length; i++) {
        const c = html[i];
        if (esc) { esc = false; continue; }
        if (c === "\\") { esc = true; continue; }
        if (c === "'") { inStr = !inStr; continue; }
        if (inStr) continue;
        if (c === "{") depth++;
        else if (c === "}") {
            depth--;
            if (depth === 0) return html.slice(start, i + 1);
        }
    }
    return null;
}

// Convert the JS-literal stateObject (single quotes) into the form-post
// value DevExpress expects: JSON with " replaced by &quot;.
function gateGridLiteralToFormValue(literal) {
    return literal.replace(/'/g, '"').replace(/"/g, "&quot;");
}

function gateGridLiteralKeys(literal) {
    if (!literal) return [];
    try { return (JSON.parse(literal.replace(/'/g, '"')).keys) || []; }
    catch (_) { return []; }
}

function gateDecodeEntities(s) {
    // Order matters: DevExpress double-encodes attribute values. The JSON
    // gets &quot;-encoded first (their pseudo-escape) and then HTML-attribute
    // encoded (& → &amp;), so the raw bytes look like `&amp;quot;`. We must
    // unwrap &amp; FIRST so that &amp;quot; becomes &quot; and then "; if
    // we did &quot; first, &amp;quot; wouldn't match anything and the JSON
    // would stay broken.
    return String(s)
        .replace(/&amp;/g, "&")
        .replace(/&quot;/g, '"')
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&#39;/g, "'");
}

// Form posts on gateaccess.net keep JSON values as &quot;-encoded entities
// instead of raw quotes. URLSearchParams URL-encodes the &/quot;/etc on top.
function gateJsonForPost(obj) {
    return JSON.stringify(obj).replace(/"/g, "&quot;");
}

function gateMmddyyyyParts(mmddyyyy) {
    const m = String(mmddyyyy || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!m) return null;
    return { m: +m[1], d: +m[2], y: +m[3] };
}
function gateDateMs(mmddyyyy) {
    const p = gateMmddyyyyParts(mmddyyyy);
    return p ? Date.UTC(p.y, p.m - 1, p.d) : 0;
}
function gateDateShort(mmddyyyy) {
    const p = gateMmddyyyyParts(mmddyyyy);
    return p ? `${p.m}/${p.d}/${p.y}` : "";
}
function gateDateLongEv(mmddyyyy) {
    const p = gateMmddyyyyParts(mmddyyyy);
    if (!p) return "";
    const pad = (n) => String(n).padStart(2, "0");
    return `${pad(p.m)}/${pad(p.d)}/${p.y} 00:00:00`;
}

// __CALLBACKPARAM for the ASPxGridView UpdateEdit callback.
// Format: c0:EV|<len>;<count>;<field>;...;KV|<len>;<keysJson>;CT|2;{};CR|2;{};GB|13;10|UPDATEEDIT;
function gateBuildCallbackParam(guest, keys) {
    const ln = String(guest.lastName || "");
    const fn = String(guest.firstName || "");
    const startEv = gateDateLongEv(guest.startDate);
    const endEv   = gateDateLongEv(guest.endDate);

    const fields = [
        `3,${ln.length},${ln}`,
        `4,${fn.length},${fn}`,
        `5,${startEv.length},${startEv}`,
        `6,${endEv.length},${endEv}`,
        `10,-1,`,
        `11,5,false`,
    ];
    // Each field gets a trailing ; in the section content; the section is
    // then closed with another ; (handled by the join below).
    const evContent = `${fields.length};` + fields.join(";") + ";";
    const keysJson = JSON.stringify(keys || []);

    return (
        "c0:" +
        `EV|${evContent.length};${evContent};` +
        `KV|${keysJson.length};${keysJson};` +
        "CT|2;{};" +
        "CR|2;{};" +
        "GB|13;10|UPDATEEDIT;"
    );
}

async function gateHttpFetchGuestPage() {
    const r = await fetch(GATE_BASE + "/GuestsDevices.aspx", {
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        referrer: GATE_BASE + "/overview.aspx",
        referrerPolicy: "unsafe-url",
    });
    if (!r.ok) throw new Error(`Could not load /GuestsDevices.aspx (HTTP ${r.status})`);
    const html = await r.text();
    if (/login\.aspx/i.test(r.url) || /<title>[^<]*Login[^<]*<\/title>/i.test(html)) {
        return { needsLogin: true };
    }
    const inputs = gateParseHiddenInputs(html);
    if (!inputs.__VIEWSTATE) {
        return { needsLogin: true };
    }
    // Augment with the gridview state read from the inline JS literal —
    // it isn't in the static HTML as a hidden input, but the form post
    // expects the synthesized value.
    const stateLiteral = gateExtractGridStateLiteral(html);
    if (stateLiteral) {
        inputs["ctl00$ContentPlaceHolder1$ASPxGridView1"] = gateGridLiteralToFormValue(stateLiteral);
    }
    return { needsLogin: false, html, inputs, stateLiteral };
}

// Pull the <option value=""> values for the community-code dropdown out of
// the login HTML. ASP.NET EventValidation 500s if we POST a value that isn't
// in this list — so we use it both to validate before submitting and to
// surface a precise error if the sheet has the wrong cc.
function gateExtractDropdownValues(html) {
    const sel = html.match(/<select[^>]*name="[^"]*DropDownListClassic"[^>]*>([\s\S]*?)<\/select>/i);
    if (!sel) return null;
    const values = [];
    const re = /<option[^>]*value="([^"]*)"/gi;
    let m;
    while ((m = re.exec(sel[1])) !== null) values.push(m[1]);
    return values;
}

// Wipe every cookie scoped to gateaccess.net. We only call this when the
// user is logging in via the extension — at that moment they're not logged
// in (otherwise we wouldn't be here), so there's no live session to disturb.
// Stale cookies are the most plausible cause of an opaque login 500: an
// expired session id or a duplicated ASP.NET_SessionId across domains can
// make the server throw on POST validation while still rendering the GET.
async function gateClearGateCookies() {
    try {
        const cookies = await chrome.cookies.getAll({ domain: "gateaccess.net" });
        for (const c of cookies) {
            const host = c.domain.startsWith(".") ? c.domain.slice(1) : c.domain;
            await chrome.cookies.remove({
                url: "https://" + host + c.path,
                name: c.name,
                storeId: c.storeId,
            });
        }
        return cookies.length;
    } catch (e) {
        return -1;
    }
}

async function gateHttpLogin(creds) {
    await gateClearGateCookies();
    const r1 = await fetch(GATE_BASE + "/login.aspx", {
        credentials: "include",
        cache: "no-store",
    });
    if (!r1.ok) throw new Error("Login GET failed: HTTP " + r1.status);
    const html = await r1.text();
    const inputs = gateParseHiddenInputs(html);

    // Sanity check the GET landed on a real login page. Stale cookies can
    // cause /login.aspx to redirect somewhere else (or render a stub) — if we
    // POST with that page's __VIEWSTATE the server returns 500 because the
    // VIEWSTATE/EventValidation pair doesn't authorise the login button.
    const r1Url = r1.url;
    const hasLoginButton = /name="[^"]*ASPxRoundPanel1\$ButtonLogin"/i.test(html)
                        || /id="[^"]*ASPxRoundPanel1_ButtonLogin"/i.test(html);
    if (!hasLoginButton) {
        const t = (html.match(/<title>([^<]+)<\/title>/i)?.[1] || "").trim();
        throw new Error(
            `GET /login.aspx didn't return the login form. Landed on: ${r1Url} ` +
            `(title="${t}"). Likely cause: stale gateaccess.net cookies in this browser. ` +
            `Clear cookies for gateaccess.net and try again.`
        );
    }

    // Validate communityCode against the dropdown the server actually rendered.
    // If creds.communityCode isn't in the list, ASP.NET will 500 with a
    // generic Runtime Error and there's nothing useful in the response body.
    const ccOptions = gateExtractDropdownValues(html);
    if (ccOptions && !ccOptions.includes(creds.communityCode)) {
        const sample = ccOptions.slice(0, 8).join(", ");
        throw new Error(
            `communityCode "${creds.communityCode}" not in the login dropdown ` +
            `(${ccOptions.length} options, e.g. ${sample}…). ` +
            `Fix the Community Code column in the gate-creds sheet for this house.`
        );
    }

    const body = new URLSearchParams();
    for (const [k, v] of Object.entries(inputs)) body.append(k, v);
    body.set("__EVENTTARGET", "");
    body.set("__EVENTARGUMENT", "");
    body.append("ctl00$ContentPlaceHolder1$ASPxRoundPanel1$DropDownListClassic", creds.communityCode);
    body.append("ctl00$ContentPlaceHolder1$ASPxRoundPanel1$UserName", creds.username);
    body.append("ctl00$ContentPlaceHolder1$ASPxRoundPanel1$Password", creds.password);
    body.append("ctl00$ContentPlaceHolder1$ASPxRoundPanel1$ButtonLogin", "Login");

    // Explicit Referer + Origin via referrer option — without these the
    // ASP.NET pipeline can return HTTP 500 because anti-CSRF middleware
    // doesn't recognise a chrome-extension:// origin.
    const r2 = await fetch(GATE_BASE + "/login.aspx", {
        method: "POST",
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        referrer: GATE_BASE + "/login.aspx",
        referrerPolicy: "unsafe-url",
        headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
        body: body.toString(),
    });
    if (!r2.ok) {
        // Aggressive diagnostics: response headers + selected body markers.
        // The Runtime Error YSOD body is opaque on remote, but sometimes the
        // headers carry an X-AspNet-* or X-Powered-By hint, and occasionally
        // the body has a stack trace fragment past the boilerplate.
        const headersDump = [];
        try {
            for (const [k, v] of r2.headers.entries()) {
                if (/^(content-type|content-length|server|x-|cache-control)/i.test(k)) {
                    headersDump.push(`${k}=${v}`);
                }
            }
        } catch (_) { /* unreadable */ }

        let peek = "";
        try {
            const t = await r2.text();
            // Surface anything past the boilerplate <style>…</style>:
            // RemoteOnly hides "Description" but sometimes leaves "Source File"
            // / "Stack Trace" markers visible.
            const afterStyle = t.slice(t.indexOf("</style>") + 8);
            const interesting = afterStyle.match(/<\/h2>([\s\S]{0,1500})/i);
            const interestingText = (interesting ? interesting[1] : afterStyle.slice(0, 1500))
                .replace(/<[^>]+>/g, " ")
                .replace(/\s+/g, " ")
                .trim();
            peek = `body-len=${t.length} body=[${interestingText.slice(0, 600)}]`;
        } catch (_) { /* body unreadable */ }
        throw new Error(
            `Login POST failed: HTTP ${r2.status} (cc="${creds.communityCode}", user="${creds.username}", get-url=${r1Url}, body-len=${body.toString().length}). ` +
            `headers=[${headersDump.join("; ")}] ${peek}`
        );
    }
    if (/login\.aspx/i.test(r2.url)) {
        throw new Error("Login rejected — wrong credentials or community code (" + creds.communityCode + ")");
    }
}

// Build the full body including all grid + form fields. Caller supplies the
// hidden inputs (parsed from the HTML snapshot it's submitting against),
// which fields to override (overrides), and which __CALLBACKID/__CALLBACKPARAM
// to use. EVENTTARGET/ARGUMENT are taken from overrides if present.
function gateBuildPostBody(inputs, overrides, callbackId, callbackParam, guest) {
    const sdShort = guest ? gateDateShort(guest.startDate) : "";
    const edShort = guest ? gateDateShort(guest.endDate)   : "";
    const sdMs    = guest ? gateDateMs(guest.startDate)    : 0;
    const edMs    = guest ? gateDateMs(guest.endDate)      : 0;
    const lastName  = guest ? (guest.lastName || "")  : "";
    const firstName = guest ? (guest.firstName || "") : "";

    const body = new URLSearchParams();
    // Start by including every hidden input we found — this guarantees
    // any framework-required tokens (__VIEWSTATEGENERATOR, __EVENTVALIDATION,
    // ASPxAutoSync, etc.) ride along. We then use set() for __EVENTTARGET
    // and __EVENTARGUMENT so they are overridden cleanly. The other
    // non-hidden fields are appended below; servers tolerate duplicates.
    for (const [k, v] of Object.entries(inputs)) {
        if (k === "ctl00$ContentPlaceHolder1$ASPxGridView1") continue;
        body.append(k, v);
    }
    body.set("__EVENTTARGET", overrides.__EVENTTARGET || "");
    body.set("__EVENTARGUMENT", overrides.__EVENTARGUMENT || "");
    body.append("ctl00$ASPxBinaryImage1$State", gateJsonForPost({ uploadedFileName: "" }));
    body.append("ctl00$ASPxTabControl1", gateJsonForPost({ activeTabIndex: 5 }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1", inputs["ctl00$ContentPlaceHolder1$ASPxGridView1"] || "");
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXSE$State", gateJsonForPost({ rawValue: "" }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXSE", "");
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEFormState", gateJsonForPost({ windowsState: "0:0:-1:502:317:0:-10000:-10000:1:0:0:0" }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor3", lastName);
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor4", firstName);
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor5$State", gateJsonForPost({ rawValue: sdMs ? String(sdMs) : "N", useMinDateInsteadOfNull: false }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor5", sdShort);
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor5$DDDState", gateJsonForPost({ windowsState: "0:0:-1:0:0:0:-10000:-10000:1:0:0:0" }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor5$DDD$C", gateJsonForPost({ visibleDate: sdShort || "", initialVisibleDate: sdShort || "", selectedDates: [] }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor6$State", gateJsonForPost({ rawValue: edMs ? String(edMs) : "N", useMinDateInsteadOfNull: false }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor6", edShort);
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor6$DDDState", gateJsonForPost({ windowsState: "0:0:-1:0:0:0:-10000:-10000:1:0:0:0" }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor6$DDD$C", gateJsonForPost({ visibleDate: edShort || "", initialVisibleDate: edShort || "", selectedDates: [] }));
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor10", "");
    body.append("ctl00$ContentPlaceHolder1$ASPxGridView1$DXPEForm$DXEFL$DXEditor11", "U");
    body.append("ctl00$ContentPlaceHolder1$ASPxPopupControl2State", gateJsonForPost({ windowsState: "0:0:-1:0:0:0:-10000:-10000:1:0:0:0" }));
    body.append("ctl00$ContentPlaceHolder1$ASPxPopupControl2$ASPxPanel1$ASPxTextBox1$State", gateJsonForPost({ rawValue: "" }));
    body.append("ctl00$ContentPlaceHolder1$ASPxPopupControl2$ASPxPanel1$ASPxTextBox1", "");
    body.append("ctl00$ContentPlaceHolder1$ASPxHiddenField1", gateJsonForPost({ data: "12|#|#" }));
    body.append("ctl00$ContentPlaceHolder1$HiddenField1", "");
    body.append("ctl00$ContentPlaceHolder1$HiddenField2", "");
    body.append("ctl00$ContentPlaceHolder1$HiddenField3", "");
    // DXScript/DXCss/__EVENTVALIDATION already came in via the loop above.
    if (callbackId) body.append("__CALLBACKID", callbackId);
    if (callbackParam) body.append("__CALLBACKPARAM", callbackParam);
    return body;
}

async function gateHttpAddOneGuest(g) {
    // Step 1 — fetch the grid page to seed __VIEWSTATE and the gridview
    // state literal. We compare the SET of row keys before/after (not the
    // count — the grid is paginated to 20 so a successful insert pushes
    // an old key off the page).
    const pageState = await gateHttpFetchGuestPage();
    if (pageState.needsLogin) {
        throw new Error("Session lost — re-fetching landed on login");
    }
    let inputs = pageState.inputs;
    let stateLiteral = pageState.stateLiteral;
    const keysBefore = new Set(gateGridLiteralKeys(stateLiteral));

    // Server may already be in edit mode from a prior partial submit; in that
    // case the inline edit form is already rendered and the Add postback
    // would be a no-op (or worse, leave the server in a weird state).
    const alreadyInEditMode = /DXEFL_DXEditor3_I/.test(pageState.html);

    if (!alreadyInEditMode) {
        // Step 2 — emulate the Add button via the standard ASP.NET WebForms
        // submit mechanism: __EVENTTARGET stays empty, the button is
        // identified by including its name=value pair in the body.
        const addBody = gateBuildPostBody(
            inputs,
            { __EVENTTARGET: "", __EVENTARGUMENT: "" },
            null, null, null,
        );
        addBody.append("ctl00$ContentPlaceHolder1$ASPxButton1", "Add a New Guest/FastAccess Pass");
        const addRes = await fetch(GATE_BASE + "/GuestsDevices.aspx", {
            method: "POST",
            credentials: "include",
            cache: "no-store",
            redirect: "follow",
            referrer: GATE_BASE + "/GuestsDevices.aspx",
            referrerPolicy: "unsafe-url",
            headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8" },
            body: addBody.toString(),
        });
        if (!addRes.ok) throw new Error("Add postback HTTP " + addRes.status);
        const addHtml = await addRes.text();
        if (/login\.aspx/i.test(addRes.url)) throw new Error("Add postback redirected to login");
        const newInputs = gateParseHiddenInputs(addHtml);
        if (!newInputs.__VIEWSTATE) throw new Error("Add postback returned a page with no VIEWSTATE");
        if (!/DXEFL_DXEditor3_I/.test(addHtml)) {
            throw new Error("Add postback didn't open the edit form — button click didn't fire");
        }
        inputs = newInputs;
        stateLiteral = gateExtractGridStateLiteral(addHtml);
        if (stateLiteral) {
            inputs["ctl00$ContentPlaceHolder1$ASPxGridView1"] = gateGridLiteralToFormValue(stateLiteral);
        }
    }
    const keys = gateGridLiteralKeys(stateLiteral);

    const sdShort = gateDateShort(g.startDate);
    const edShort = gateDateShort(g.endDate);
    if (!sdShort || !edShort) throw new Error("Bad date format (need MM/DD/YYYY)");

    // Step 3 — UPDATEEDIT callback against the now-in-edit-mode page.
    const callbackParam = gateBuildCallbackParam(g, keys);
    const body = gateBuildPostBody(
        inputs,
        { __EVENTTARGET: "", __EVENTARGUMENT: "" },
        "ctl00$ContentPlaceHolder1$ASPxGridView1",
        callbackParam,
        g,
    );

    const r = await fetch(GATE_BASE + "/GuestsDevices.aspx", {
        method: "POST",
        credentials: "include",
        cache: "no-store",
        redirect: "follow",
        referrer: GATE_BASE + "/GuestsDevices.aspx",
        referrerPolicy: "unsafe-url",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "X-Requested-With": "XMLHttpRequest",
        },
        body: body.toString(),
    });
    if (!r.ok) throw new Error("Update HTTP " + r.status);
    const respText = await r.text();
    if (/login\.aspx/i.test(r.url)) throw new Error("Logged out mid-request");
    // DevExpress callback errors are embedded as `'error':{'message':'...'}`
    // somewhere in the response.
    const errMatch = respText.match(/'error':\{[^}]*'message':'([^']+)'/);
    if (errMatch) throw new Error("Server: " + errMatch[1]);

    // Verify by re-fetching and looking for a key not seen before.
    await new Promise((res) => setTimeout(res, 600));
    const verify = await fetch(GATE_BASE + "/GuestsDevices.aspx", { credentials: "include" });
    const verifyHtml = await verify.text();
    const verifyLiteral = gateExtractGridStateLiteral(verifyHtml);
    const keysVerify = gateGridLiteralKeys(verifyLiteral);
    const newKey = keysVerify.find((k) => !keysBefore.has(k));
    if (!newKey) {
        const respPeek = respText.slice(0, 250).replace(/\s+/g, " ");
        throw new Error(
            "Submitted but no new row appeared. Response head: " + respPeek
        );
    }
}

async function gateAddGuests({ house, guests }) {
    if (!house) throw new Error("house required");
    if (!Array.isArray(guests) || guests.length === 0) throw new Error("guests must be a non-empty array");

    const creds = await gateCredsForHouse(house);

    // Run gatePageRunner inside a popup window, then close the window.
    //
    // Brave pauses the renderer in background tabs / non-focused windows,
    // so the gateaccess.net DevExpress JS never inits and the dropdown
    // never appears. Workaround: open the popup *focused* so the renderer
    // starts in foreground state, immediately give the user's window its
    // focus back, and minimize the popup. The popup is then invisible to
    // the user (minimized to the dock) but its renderer keeps running
    // because it already booted in foreground. The "focus theft" is just
    // a few hundred ms — long enough for Brave to commit to running the
    // renderer at full speed.
    const url = GATE_BASE + "/login.aspx";
    const prevWin = await chrome.windows.getCurrent().catch(() => null);
    let win;
    try {
        win = await chrome.windows.create({
            url,
            type: "popup",
            focused: true,
            width: 800,
            height: 600,
            top: 0,
            left: 0,
        });
    } catch (e) {
        throw new Error("windows.create failed: " + (e?.message || e));
    }
    // Give focus back to the user's previous window AND minimize the
    // popup so they don't see it. Race is fine — even if the popup is
    // visible for ~150 ms it's not stealing the window away from real
    // work, and from then on it lives in the dock.
    if (prevWin && prevWin.id !== win.id) {
        chrome.windows.update(prevWin.id, { focused: true }).catch(() => {});
    }
    chrome.windows.update(win.id, { state: "minimized" }).catch(() => {});
    const tabId = win.tabs && win.tabs[0] && win.tabs[0].id;
    if (!tabId) throw new Error("popup window opened with no tab");
    try {
        // Wait for the login page to finish loading.
        await new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                chrome.tabs.onUpdated.removeListener(onUpdated);
                reject(new Error("tab load timed out after 25s"));
            }, 25000);
            const onUpdated = (id, changeInfo) => {
                if (id === tabId && changeInfo.status === "complete") {
                    clearTimeout(timeout);
                    chrome.tabs.onUpdated.removeListener(onUpdated);
                    resolve();
                }
            };
            chrome.tabs.onUpdated.addListener(onUpdated);
        });
        // DevExpress finishes wiring up after 'complete'.
        await new Promise((r) => setTimeout(r, 800));

        const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: gatePageRunner,
            args: [{ creds, guests }],
        });
        const wrapped = results && results[0] && results[0].result;
        if (!wrapped) throw new Error("gatePageRunner returned no result");
        if (!wrapped.ok) throw new Error(wrapped.error || "gatePageRunner returned error");
        return wrapped.data;
    } finally {
        chrome.windows.remove(win.id).catch(() => {});
    }
}

// Runs in MAIN world of gateaccess.net. Logs in once, then loops through
// `guests` clicking Add → fill → Update for each.
async function gatePageRunner({ creds, guests }) {
    try {
        const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
        const waitFor = async (sel, timeoutMs = 20000) => {
            const t0 = Date.now();
            while (Date.now() - t0 < timeoutMs) {
                const el = document.querySelector(sel);
                if (el && (el.offsetParent !== null || el.tagName === "SELECT")) return el;
                await sleep(120);
            }
            const selects = Array.from(document.querySelectorAll("select"))
                .map((s) => s.id || s.name).slice(0, 8).join(", ");
            throw new Error(
                "Timed out waiting for: " + sel +
                " (at " + location.pathname + ", title='" + document.title +
                "', body=" + document.body.children.length +
                "el, selects=[" + selects + "])"
            );
        };

        // ----- Login (only on /login.aspx) -----
        if (/login\.aspx/i.test(location.pathname)) {
            // Try id, then name suffix as fallback (handles minor renames).
            const ccSel = await waitFor(
                '#ctl00_ContentPlaceHolder1_ASPxRoundPanel1_DropDownListClassic, ' +
                'select[name$="DropDownListClassic"]'
            );
            ccSel.value = creds.communityCode;
            ccSel.dispatchEvent(new Event("change", { bubbles: true }));
            const userInput = document.getElementById('ctl00_ContentPlaceHolder1_ASPxRoundPanel1_UserName_I');
            const passInput = document.getElementById('ctl00_ContentPlaceHolder1_ASPxRoundPanel1_Password_I');
            if (!userInput || !passInput) throw new Error("Login form not found");
            userInput.value = creds.username;
            passInput.value = creds.password;
            userInput.dispatchEvent(new Event("change", { bubbles: true }));
            passInput.dispatchEvent(new Event("change", { bubbles: true }));
            // Login button id confirmed via DOM inspection on gateaccess.net.
            const btn = document.getElementById('ctl00_ContentPlaceHolder1_ASPxRoundPanel1_ButtonLogin_I') ||
                        document.getElementById('ctl00_ContentPlaceHolder1_ASPxRoundPanel1_ButtonLogin');
            if (!btn) throw new Error("Login button not found (#...ButtonLogin_I)");
            btn.click();
            const t0 = Date.now();
            while (Date.now() - t0 < 20000) {
                if (!/login\.aspx/i.test(location.pathname)) break;
                await sleep(200);
            }
            if (/login\.aspx/i.test(location.pathname)) {
                throw new Error("Login failed (still on login page) — wrong username/password/community?");
            }
        }

        // ----- Navigate to Guest List -----
        if (!/guests/i.test(location.pathname)) {
            location.href = "/GuestsDevices.aspx";
            const t0 = Date.now();
            while (Date.now() - t0 < 15000) {
                if (/guests/i.test(location.pathname)) break;
                await sleep(200);
            }
        }
        await waitFor('#ctl00_ContentPlaceHolder1_ASPxButton1_I');

        const results = [];
        for (let i = 0; i < guests.length; i++) {
            const g = guests[i];
            const lastName = String(g.lastName || "").trim();
            const firstName = String(g.firstName || "").trim();
            try {
                if (!lastName) throw new Error("missing last name");

                // Click "Add a New Guest/FastAccess Pass"
                const addBtn = document.getElementById('ctl00_ContentPlaceHolder1_ASPxButton1_I');
                if (!addBtn) throw new Error("Add button not found");
                addBtn.click();

                // Wait for the inline edit form
                await waitFor('#ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor3_I');
                // Tiny breath for DevExpress to fully wire up
                await sleep(250);

                const setVal = (id, value) => {
                    const el = document.getElementById(id);
                    if (!el) return;
                    el.value = value || "";
                    el.dispatchEvent(new Event("input", { bubbles: true }));
                    el.dispatchEvent(new Event("change", { bubbles: true }));
                    el.dispatchEvent(new Event("blur", { bubbles: true }));
                    // For DevExpress controls, also poke the client object so
                    // it updates the hidden _State field. Without this the
                    // server rejects the postback with "Invalid value for state".
                    const baseId = id.replace(/_I$/, "");
                    const ctrl = window[baseId];
                    if (ctrl) {
                        try {
                            if (typeof ctrl.SetText === "function") ctrl.SetText(value || "");
                            else if (typeof ctrl.SetValue === "function") ctrl.SetValue(value || null);
                        } catch (_) { /* ignore — fallback events above */ }
                    }
                };
                const setDate = (id, mmddyyyy) => {
                    const baseId = id.replace(/_I$/, "");
                    const ctrl = window[baseId];
                    const m = String(mmddyyyy || "").match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
                    if (!m) { setVal(id, mmddyyyy); return; }
                    const yyyy = m[3], mm = m[1].padStart(2, "0"), dd = m[2].padStart(2, "0");

                    // Preferred: DevExpress client API.
                    if (ctrl && typeof ctrl.SetDate === "function") {
                        try {
                            ctrl.SetDate(new Date(+yyyy, +m[1] - 1, +dd));
                            return;
                        } catch (_) { /* fall through */ }
                    }

                    // Fallback: write the visible input AND the hidden _State
                    // JSON the postback validator reads. Without rawValue here
                    // the server replies with "Invalid value for state".
                    const visEl = document.getElementById(id);
                    if (visEl) {
                        visEl.value = mmddyyyy;
                        visEl.dispatchEvent(new Event("change", { bubbles: true }));
                    }
                    const stateEl = document.getElementById(baseId + "_State");
                    if (stateEl) {
                        let stateObj;
                        try { stateObj = JSON.parse(stateEl.value || "{}"); }
                        catch (_) { stateObj = {}; }
                        stateObj.rawValue = `${yyyy}-${mm}-${dd}`;
                        stateEl.value = JSON.stringify(stateObj);
                    }
                };
                setVal('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor3_I', lastName);
                setVal('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor4_I', firstName);
                setDate('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor5_I', g.startDate || '');
                setDate('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor6_I', g.endDate || '');
                setVal('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor10_I', g.notes || '');

                await sleep(200);

                // Click Update
                const updateBtn = document.getElementById('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXCBtn60_I');
                if (!updateBtn) throw new Error("Update button not found");
                updateBtn.click();

                // Wait for the form to disappear (it's gone when the row was saved)
                const t0 = Date.now();
                let formGone = false;
                while (Date.now() - t0 < 12000) {
                    const editor = document.getElementById('ctl00_ContentPlaceHolder1_ASPxGridView1_DXPEForm_DXEFL_DXEditor3_I');
                    if (!editor || editor.offsetParent === null) { formGone = true; break; }
                    await sleep(250);
                }
                if (!formGone) throw new Error("Form did not close after Update — submit may have failed");

                // Verify in the rendered grid
                await sleep(500);
                const html = document.body.innerHTML;
                const verified = html.includes(lastName) && (firstName ? html.includes(firstName) : true);
                results.push({ lastName, firstName, ok: !!verified, error: verified ? null : "submitted but not visible in grid" });
            } catch (e) {
                results.push({ lastName, firstName, ok: false, error: String(e?.message || e) });
            }
        }
        return { ok: true, data: { results } };
    } catch (e) {
        return { ok: false, error: String(e?.message || e) };
    }
}

chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
    (async () => {
        try {
            if (!msg || typeof msg !== "object") {
                sendResponse({ ok: false, error: "invalid message" });
                return;
            }
            if (msg.action === "ping") {
                sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
                return;
            }
            if (msg.action === "jobber-query") {
                const data = await jobberFetch(msg.payload || {});
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "mapro-add-comment") {
                const data = await maproAddComment(msg.payload || {});
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "mapro-add-service") {
                const data = await maproAddService(msg.payload || {});
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "mapro-list-services") {
                const data = await maproListServices(msg.payload || {});
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "gate-creds-status") {
                const data = await gateCredsStatus();
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "gate-ensure-creds") {
                const data = await gateEnsureCreds();
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "gate-add-guests") {
                const data = await gateAddGuests(msg.payload || {});
                sendResponse({ ok: true, data });
                return;
            }
            if (msg.action === "gate-get-creds-for-resort") {
                // For systems where one login covers every house (Windsor
                // Island, Lake Berkley, …) the page identifies the row by
                // resort name and the actual house is picked downstream.
                const resort = (msg.payload && msg.payload.resort) || "";
                const creds = await gateCredsForResort(resort);
                sendResponse({ ok: true, data: {
                    house: creds.house,
                    resort: creds.resort,
                    username: creds.username,
                    password: creds.password,
                } });
                return;
            }
            if (msg.action === "push-templates") {
                // MasterBot site pushes the operator's templates so the
                // airbnb-slash content script can show them offline. We
                // just stash the latest snapshot in storage.
                const payload = msg.payload || {};
                await chrome.storage.local.set({
                    airbnbSlashCache: {
                        templates: Array.isArray(payload.templates) ? payload.templates : [],
                        slugByName: payload.slugByName && typeof payload.slugByName === "object" ? payload.slugByName : {},
                        yourName: typeof payload.yourName === "string" ? payload.yourName : "",
                        signatureText: typeof payload.signatureText === "string" ? payload.signatureText : "",
                        ts: Date.now(),
                    },
                });
                sendResponse({ ok: true });
                return;
            }
            if (msg.action === "gate-get-creds-for-house") {
                // Returns creds for any resort — the page picks the right
                // integration based on the row's resort field. For Champions
                // Gate the cc + username/password go to /api/gate/add. For
                // Windsor Island (Proptia) we need email + password.
                const house = (msg.payload && msg.payload.house) || "";
                if (!house) throw new Error("house required");
                const creds = await gateCredsForHouse(house);
                sendResponse({ ok: true, data: {
                    house: creds.house,
                    resort: creds.resort,
                    communityCode: creds.communityCode || "",
                    username: creds.username,
                    password: creds.password,
                } });
                return;
            }
            sendResponse({ ok: false, error: `unknown action: ${msg.action}` });
        } catch (e) {
            sendResponse({ ok: false, error: String(e?.message || e) });
        }
    })();
    return true;
});

// ===== Airbnb Claude reply (Phase 1) =====
const AIRBNB_API_KEY = "d306zoyjsyarp7ifhu67rjxn52tv0t20";
const VIADUCT_THREAD_HASH =
  "8a30e768581661887cf9eb7f87b0b9be4b6b935ff2159f1c72e233c303976689";
const HOST_ACCOUNT_ID = "93929916";
// The brain runs on the Mac. Default targets localhost (works when the
// browser is on the Mac itself). To reach it from another computer over
// Tailscale, set the address once on that machine — it overrides this:
//   chrome.storage.local.set({airbnbDraftBase: "http://<mac>.<tailnet>.ts.net:8787"})
const DRAFT_BASE_DEFAULT = "http://localhost:8787";

async function draftServerBase() {
  const { airbnbDraftBase } = await chrome.storage.local.get("airbnbDraftBase");
  return airbnbDraftBase || DRAFT_BASE_DEFAULT;
}

async function draftServerUrl() {
  return (await draftServerBase()) + "/api/draft-adhoc";
}

async function fetchAirbnbThread(numericId) {
  const variables = {
    numRequestedMessages: 50, getThreadState: true, getParticipants: true,
    getLastReads: true, forceUgcTranslation: false, isNovaLite: false,
    globalThreadId: btoa("MessageThread:" + numericId), originType: "USER_INBOX",
    getInboxFields: true, getInboxOnlyFields: false, getMessageFields: true,
    getThreadOnlyFields: true, skipOldMessagePreviewFields: false,
  };
  const extensions = { persistedQuery: { version: 1, sha256Hash: VIADUCT_THREAD_HASH } };
  const url = `https://www.airbnb.com/api/v3/ViaductGetThreadAndDataQuery/${VIADUCT_THREAD_HASH}`
    + `?operationName=ViaductGetThreadAndDataQuery&locale=en&currency=USD`
    + `&variables=${encodeURIComponent(JSON.stringify(variables))}`
    + `&extensions=${encodeURIComponent(JSON.stringify(extensions))}`;
  const res = await fetch(url, {
    credentials: "include",
    headers: {
      "content-type": "application/json",
      "x-airbnb-api-key": AIRBNB_API_KEY,
      "x-airbnb-graphql-platform": "web",
      "x-csrf-without-token": "1",
    },
  });
  if (!res.ok) throw new Error(`Airbnb thread fetch ${res.status} (persisted-query hash may have rotated)`);
  const json = await res.json();
  if (json && json.errors && json.errors.length) {
    throw new Error(`Airbnb GraphQL: ${json.errors[0].message || "error"} (session expired or hash rotated?)`);
  }
  return json;
}

function mapThreadToPayload(json) {
  const td = json && json.data && json.data.threadData;
  if (!td) throw new Error("no threadData in Airbnb response");
  const parts = (td.participants && td.participants.edges || []).map((e) => e.node);
  const guest = parts.find((n) => n && n.participantRole === "GUEST");
  const guestName =
    (guest && guest.enrichedParticipantInfo && guest.enrichedParticipantInfo.name) ||
    (td.inboxTitle && td.inboxTitle.components && td.inboxTitle.components[0] &&
      td.inboxTitle.components[0].text) || "Guest";
  const desc = (td.inboxDescription && td.inboxDescription.components &&
    td.inboxDescription.components[0] && td.inboxDescription.components[0].text) || "";
  const listing = desc.includes("·") ? desc.split("·").pop().trim() : "";
  const tripTag = (td.userThreadTags || []).find((t) => t.userThreadTagName === "trip_stages");
  const tripStage = (tripTag && tripTag.additionalValues && tripTag.additionalValues[0]) || "";
  const msgs = (td.messageData && td.messageData.messages || []).map((m) => ({
    accountType: m.account && m.account.accountType,
    accountId: m.account && m.account.accountId,
    createdAtMs: m.createdAtMs,
    body: (m.hydratedContent && m.hydratedContent.contentType === "TEXT" &&
      m.hydratedContent.content && m.hydratedContent.content.body) || "",
    sender_name: (m.account && String(m.account.accountId) === HOST_ACCOUNT_ID) ? "team" : guestName,
  }));
  // The booking's confirmation code (when the thread has a reservation) lets
  // the server pull full MAPRO context — dates, door code, availability.
  const confirmationCode =
    (td.threadContent && td.threadContent.detailPanel &&
      td.threadContent.detailPanel.sidebarParams &&
      td.threadContent.detailPanel.sidebarParams.confirmationCode) || "";
  return { guest_name: guestName, listing, trip_stage: tripStage, confirmation_code: confirmationCode, messages: msgs };
}

async function draftAirbnbThread(numericId) {
  const threadJson = await fetchAirbnbThread(numericId);
  const payload = mapThreadToPayload(threadJson);
  let res;
  try {
    res = await fetch(await draftServerUrl(), {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    // fetch only rejects on a genuine connection failure — the one case
    // where the Tailscale/server-reachability hint is actually relevant.
    throw new Error(`Can't reach the draft server — is airbnb-app running and reachable over Tailscale on :8787? (${e.message})`);
  }
  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json()).detail || ""; } catch (_) {}
    if (res.status === 400 && /no messages/i.test(detail)) {
      throw new Error("This conversation has no text messages to draft a reply from (system-only or empty thread).");
    }
    throw new Error(`Draft server ${res.status}${detail ? ": " + detail : ""}`);
  }
  return res.json();
}

// ----- Batch: draft every unread inbox thread -----

const DRAFTS_KEY = "airbnbDrafts";
const BATCH_CONCURRENCY = 3;
let batchCancel = false;

async function getDrafts() {
  const o = await chrome.storage.local.get(DRAFTS_KEY);
  return o[DRAFTS_KEY] || {};
}

async function patchDraft(numericId, fields) {
  const drafts = await getDrafts();
  drafts[numericId] = Object.assign({}, drafts[numericId], fields, { ts: Date.now() });
  await chrome.storage.local.set({ [DRAFTS_KEY]: drafts });
}

// threads: [{ numericId, title }] enumerated from the inbox DOM by the
// content script (account-agnostic — no viewer-id needed).
async function draftThreads(threads) {
  batchCancel = false;
  // Seed every thread as queued so the dots appear immediately.
  const drafts = await getDrafts();
  for (const t of threads) {
    drafts[t.numericId] = { status: "queued", title: t.title, ts: Date.now() };
  }
  await chrome.storage.local.set({ [DRAFTS_KEY]: drafts });

  let idx = 0;
  async function worker() {
    while (idx < threads.length) {
      if (batchCancel) return;
      const t = threads[idx++];
      await patchDraft(t.numericId, { status: "drafting" });
      try {
        const out = await draftAirbnbThread(t.numericId);
        await patchDraft(t.numericId, {
          status: out.needs_human ? "review" : "ready",
          draft: out.draft || "",
          needs_human: !!out.needs_human,
          confidence: out.confidence,
          internal_note: out.internal_note,
          reasoning: out.reasoning,
          inserted: false,
        });
      } catch (e) {
        await patchDraft(t.numericId, {
          status: "failed", error: String((e && e.message) || e),
        });
      }
    }
  }
  const pool = [];
  for (let i = 0; i < Math.min(BATCH_CONCURRENCY, threads.length); i++) pool.push(worker());
  // Don't await pool here — return the total so the popup can close while
  // drafting continues; the content script tracks progress via storage.
  Promise.all(pool).catch(() => {});
  return threads.length;
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.action === "airbnbDraftThread") {
    (async () => {
      try {
        const out = await draftAirbnbThread(msg.threadId);
        // Store the full result so the in-thread notes panel can show the
        // confidence / internal note even for a one-off single-thread draft.
        await patchDraft(msg.threadId, {
          status: out.needs_human ? "review" : "ready",
          draft: out.draft || "",
          needs_human: !!out.needs_human,
          confidence: out.confidence,
          internal_note: out.internal_note,
          reasoning: out.reasoning,
          inserted: true,
        });
        sendResponse({ ok: true, draft: out.draft, needs_human: out.needs_human });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // keep the channel open for the async response
  }
  if (msg && msg.action === "draftThreads") {
    (async () => {
      try {
        const total = await draftThreads(msg.threads || []);
        sendResponse({ ok: true, total });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // keep the channel open for the async response
  }
  if (msg && msg.action === "resetDrafts") {
    (async () => {
      batchCancel = true; // stop any running batch
      await chrome.storage.local.remove(DRAFTS_KEY);
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (msg && msg.action === "cancelBatch") {
    (async () => {
      batchCancel = true;
      // Drop threads that never started so their gray dots clear; leave
      // drafting/ready/failed alone (those represent real work).
      const drafts = await getDrafts();
      let removed = 0;
      for (const k of Object.keys(drafts)) {
        if (drafts[k] && drafts[k].status === "queued") { delete drafts[k]; removed++; }
      }
      await chrome.storage.local.set({ [DRAFTS_KEY]: drafts });
      sendResponse({ ok: true, removed });
    })();
    return true;
  }
  if (msg && msg.action === "sendFeedback") {
    (async () => {
      try {
        const res = await fetch((await draftServerBase()) + "/api/feedback", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({
            note: msg.note, reservation_id: msg.reservation_id || "",
            draft: msg.draft || "", guest_name: msg.guest_name || "",
          }),
        });
        if (!res.ok) {
          let d = ""; try { d = (await res.json()).detail || ""; } catch (_) {}
          throw new Error(`Feedback ${res.status}${d ? ": " + d : ""}`);
        }
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, error: String((e && e.message) || e) });
      }
    })();
    return true; // keep the channel open for the async response
  }
});
